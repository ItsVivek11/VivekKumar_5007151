package com.ems.EmployeeManagementSystem.repository;

public interface DepartmentProjection {
    Integer getId();
    String getName();
}
