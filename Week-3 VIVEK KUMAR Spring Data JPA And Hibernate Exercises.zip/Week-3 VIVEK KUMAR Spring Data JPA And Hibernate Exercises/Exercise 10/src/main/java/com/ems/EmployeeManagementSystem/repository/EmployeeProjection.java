package com.ems.EmployeeManagementSystem.repository;

public interface EmployeeProjection {
    Integer getId();
    String getName();
    String getEmail();
    String getDepartmentName();
}
