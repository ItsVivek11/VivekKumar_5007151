package com.example.LibraryManagementSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementSpringBootApplication.class, args);
	}

}
