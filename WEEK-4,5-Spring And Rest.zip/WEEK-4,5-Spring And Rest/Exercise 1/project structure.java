BookstoreAPI/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── example/
│   │   │           └── BookstoreAPI/
│   │   │               └── BookstoreAPIApplication.java
│   │   ├── resources/
│   │   │   └── application.properties
│   │   └── test/
│   │       └── java/
│   │           └── com/
│   │               └── example/
│   │                   └── BookstoreAPI/
│   │                       └── BookstoreAPIApplicationTests.java
│   └── target/
└── pom.xml (or build.gradle)