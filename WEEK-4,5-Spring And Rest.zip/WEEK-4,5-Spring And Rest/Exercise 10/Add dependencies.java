<!-- Maven -->
<dependency>
    <groupId>com.fasterxml.jackson.dataformat</groupId>
    <artifactId>jackson-dataformat-xml</artifactId>
</dependency>

<!-- Gradle -->
dependencies {
    implementation 'com.fasterxml.jackson.dataformat:jackson-dataformat-xml'
}