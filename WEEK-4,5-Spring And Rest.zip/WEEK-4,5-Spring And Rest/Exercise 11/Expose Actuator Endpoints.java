management.endpoints.web.exposure.include=*
management.endpoint.health.show-details=always