<!-- Maven -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>

<!-- Gradle -->
dependencies {
    implementation 'org.springframework.boot:spring-boot-starter-actuator'
}